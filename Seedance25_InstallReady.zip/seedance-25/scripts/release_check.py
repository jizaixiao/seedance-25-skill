#!/usr/bin/env python3
"""Offline source/installed link closure, version semantics and exact hash gate."""
from pathlib import Path
from urllib.parse import urlsplit, unquote
import argparse
import json
import re
import subprocess
import sys
import tempfile
from install_codex_skill import rewrite_installed_readme_text

ROOT = Path(__file__).resolve().parents[1]
LINK = re.compile(r'!?\[[^\]\n]*\]\((<[^>\n]+>|[^)\n]+)\)|\b(?:src|href)=["\x27]([^"\x27]+)["\x27]')

def targets(path, root, text=None):
    text = path.read_text() if text is None else text
    for match in LINK.finditer(text):
        destination = (match.group(1) or match.group(2)).strip()
        if destination.startswith('<'): destination = destination[1:-1]
        # Strip optional Markdown link title, preserving paths inside <...>.
        parsed = urlsplit(destination)
        if parsed.scheme or parsed.netloc or not parsed.path: continue
        target = (path.parent/unquote(parsed.path)).resolve()
        yield target

def link_errors(root, paths, installed=False):
    errors=[]; count=0
    for path in paths:
        if path.suffix != '.md': continue
        text = rewrite_installed_readme_text(path.read_text()) if installed and path.name=='README.md' and path.parent==root else path.read_text()
        for target in targets(path,root,text):
            count+=1
            if not target.is_relative_to(root.resolve()) or not target.is_file():
                errors.append(f'{path.relative_to(root)} -> missing/unsafe {target}')
    return errors,count

def semantic_errors(root):
    errors=[]
    for name in ['agents/openai.yaml','scripts/install_codex_skill.py','scripts/eval_run.py']:
        text=(root/name).read_text()
        if re.search(r'seedance-20(?!\d)',text): errors.append('stale root identity: '+name)
    cases=json.loads((root/'evals/evals.json').read_text())['cases']
    existing={'seedance-25'} | {p.parent.name for p in (root/'skills').glob('*/SKILL.md')}
    for case in cases:
        if not set(case['skills_expected_to_activate']) <= existing: errors.append('nonexistent eval route: '+case['id'])
    policy=(root/'references/timing-policy.md').read_text()
    if not all(x in policy for x in ['one-second','not guaranteed','timestamp-scoped edits']): errors.append('timing contract incomplete')
    for name in ['references/model-name-map.md','references/api-status.md','references/multishot-grammar.md','references/vocab/zh.md','references/vocab/ja.md','references/vocab/ko.md']:
        text=(root/name).read_text()
        if re.search(r'(?:2\.5 does not respond to timestamps|本仓库不覆盖 2\.5|在 2\.5 上不要写绝对秒数|not covered by this skill)',text): errors.append('contradictory 2.5 scope/timing: '+name)
    active = [*(root/'skills').glob('*/SKILL.md'), *(root/'references').glob('*.md')]
    obsolete = re.compile(r'no absolute seconds inside a block on Seedance 2\.5|2\.5 does not respond to timestamps|在 2\.5 上不要写绝对秒数|separately promoted 2\.5 line')
    for path in active:
        if obsolete.search(path.read_text()): errors.append('obsolete model-line semantics: '+str(path.relative_to(root)))
    # Standard ID must not masquerade as several variants again.
    table=(root/'references/model-name-map.md').read_text()
    if table.count('`doubao-seedance-2-5-260628`') != 1: errors.append('ambiguous standard model mapping')
    return errors

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--links-only',action='store_true')
    args=parser.parse_args()
    paths=[p for p in ROOT.rglob('*.md') if '.git' not in p.parts]
    errors,count=link_errors(ROOT,paths)
    manifest=ROOT/'validation/install-payload.txt'
    declared=[l.strip() for l in manifest.read_text().splitlines() if l.strip() and not l.startswith('#')]
    allowed=set(declared)
    installed_count=0
    for name in declared:
        path=ROOT/name
        if path.suffix!='.md':continue
        text=rewrite_installed_readme_text(path.read_text()) if name=='README.md' else path.read_text()
        for target in targets(path,ROOT,text):
            installed_count+=1
            if not target.is_relative_to(ROOT): errors.append('installed link escapes root: '+name)
            elif target.relative_to(ROOT).as_posix() not in allowed: errors.append('installed link absent from payload: '+name+' -> '+str(target.relative_to(ROOT)))
    if not args.links_only:
        errors+=semantic_errors(ROOT)
        result=subprocess.run([sys.executable,str(ROOT/'scripts/refresh_manifests.py')],cwd=ROOT)
        if result.returncode:errors.append('integrity check failed')
    if errors:
        print('\n'.join('FAIL: '+x for x in errors)); return 1
    print(f'Release checks passed: {count} source links, {installed_count} installed links, {len(declared)} payload files; semantic and integrity gates applied={not args.links_only}.')
    return 0

if __name__=='__main__':raise SystemExit(main())
