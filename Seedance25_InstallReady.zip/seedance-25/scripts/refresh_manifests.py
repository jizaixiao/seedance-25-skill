#!/usr/bin/env python3
"""Explicit release-input refresh; runtime verification never repairs hashes.

Default checks only. --write re-pins reviewed eval/oracle inputs, freezes the
role-scoped source set, then seals the complete distribution except this seal.
Run after reviewing changes; historical pins are retained in docs/history.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
HASH_FILE = 'evals/revision-file-hashes.json'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def distribution_files(root):
    return sorted(p for p in root.rglob('*') if p.is_file()
                  and not any(x in {'.git', '__pycache__', '.pytest_cache'} for x in p.relative_to(root).parts)
                  and p.suffix not in {'.pyc', '.pyo'}
                  and p.relative_to(root).as_posix() != HASH_FILE)

def source_manifest(root):
    # Import only to reuse the evaluator's exact path and role contract.
    import eval_run
    sources = []
    for name in sorted(eval_run._scoped_repository_files(root)):
        if name == 'SKILL.md': role = 'root'
        elif name in {'evals/evals.json', 'references/eval-rubric.md', 'references/outcome-comparison.md', *eval_run.EVALUATOR_HARNESS_PATHS}: role = 'evaluator'
        elif name.startswith('evals/fixtures/'): role = 'fixture'
        elif name.startswith('references/migrated/'): role = 'archive'
        else: role = 'responder'
        eval_run._validate_role_path(name, role)
        sources.append({'path': name, 'role': role, 'sha256': digest(root/name)})
    return {'version': 1, 'sources': sources}

def encoded(value):
    return json.dumps(value, ensure_ascii=False, indent=2) + '\n'

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--write', action='store_true', help='explicitly replace current reviewed pins')
    args = parser.parse_args()
    harness = ROOT/'scripts/eval_run.py'
    text = harness.read_text()
    updated = text
    for constant, relative in [('EXPECTED_EVALS_SHA256', 'evals/evals.json'), ('EXPECTED_RUBRIC_SHA256', 'references/eval-rubric.md')]:
        updated, count = re.subn(r'^'+constant+r' = "[0-9a-f]{64}"$', constant+' = "'+digest(ROOT/relative)+'"', updated, flags=re.M)
        if count != 1: raise ValueError('missing or ambiguous canonical pin: '+constant)
    declaration = r'^_EXECUTED_EVALUATOR_SOURCE_SHA256 = "[0-9a-f]{64}"$'
    normalized, count = re.subn(declaration, '_EXECUTED_EVALUATOR_SOURCE_SHA256 = "'+'0'*64+'"', updated, flags=re.M)
    if count != 1: raise ValueError('missing or ambiguous evaluator self-digest')
    identity_digest = hashlib.sha256(normalized.encode('utf-8')).hexdigest()
    updated = re.sub(declaration, '_EXECUTED_EVALUATOR_SOURCE_SHA256 = "'+identity_digest+'"', updated, flags=re.M)
    if args.write:
        harness.write_text(updated)
    elif updated != text:
        print('FAIL: evaluator canonical pins differ; review edits before --write')
        return 1
    # Clear an old import only relevant to callers importing this script in-process.
    sys.modules.pop('eval_run', None)
    manifest_text = encoded(source_manifest(ROOT))
    manifest_path = ROOT/'evals/source-manifest.json'
    if args.write:
        manifest_path.write_text(manifest_text)
    elif manifest_path.read_text() != manifest_text:
        print('FAIL: current source manifest differs from the declared source boundary')
        return 1
    seal = {'generated_on': '2026-11-15', 'purpose': 'R2 distribution integrity; all regular release files except this seal; excludes bytecode and Git metadata',
            'sha256': {p.relative_to(ROOT).as_posix(): digest(p) for p in distribution_files(ROOT)}}
    if args.write:
        (ROOT/HASH_FILE).write_text(encoded(seal))
    else:
        recorded = json.loads((ROOT/HASH_FILE).read_text())
        if recorded.get('sha256') != seal['sha256']:
            old, new = recorded.get('sha256', {}), seal['sha256']
            changed = sorted(k for k in old.keys() | new.keys() if old.get(k) != new.get(k))
            print('FAIL: distribution coverage/digests differ: '+', '.join(changed[:15]))
            return 1
    print(('Refreshed' if args.write else 'Verified')+f' {len(seal["sha256"])} distribution hashes and {len(json.loads(manifest_text)["sources"])} frozen sources.')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
