from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parents[1]

class WorkflowBoundaryTests(unittest.TestCase):
    def test_revision_has_no_privileged_job(self):
        self.assertFalse((ROOT/'.github/workflows/privileged-frame-publication.yml').exists())
        for path in (ROOT/'.github/workflows').glob('*.yml'):
            text=path.read_text()
            self.assertNotIn('--privileged',text)
            self.assertNotIn('pull_request_target:',text)
            self.assertNotIn('contents: write',text)
            self.assertIn('contents: read',text)
            self.assertIn('persist-credentials: false',text)

    def test_pull_requests_have_offline_validation(self):
        text=(ROOT/'.github/workflows/validate-skills.yml').read_text()
        for command in ['pull_request:','python scripts/validate_repo.py','python scripts/release_check.py','python scripts/eval_run.py --limit 1']:
            self.assertIn(command,text)
        self.assertNotIn('--live',text)

if __name__=='__main__':unittest.main()
