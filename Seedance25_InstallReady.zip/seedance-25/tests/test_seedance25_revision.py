"""Regression behaviors for the 2.5 release, including fail-closed freeze."""
from pathlib import Path
import json
import shutil
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'scripts'))
import eval_run
import install_codex_skill
from release_check import semantic_errors, link_errors

class Seedance25RevisionTests(unittest.TestCase):
    def test_active_routes_and_oracles_resolve(self):
        self.assertEqual(semantic_errors(ROOT), [])
        self.assertEqual(install_codex_skill.SKILL_NAME, 'seedance-25')
        self.assertEqual(eval_run._expected_route_paths({'skills_expected_to_activate':['seedance-25','seedance-prompt']}), {'skills/seedance-prompt/SKILL.md'})

    def test_requested_timing_is_not_an_older_line_refusal(self):
        cases=json.loads((ROOT/'evals/evals.json').read_text())['cases']
        case=next(c for c in cases if c['id']=='newer_line_timestamp_request_stays_in_boundary')
        self.assertIn('requested continuous second-level timeline',case['expected_output'])
        self.assertNotIn('built and verified for Seedance 2.0',case['expected_output'])

    def test_short_and_full_prompt_paths_allow_supported_timing(self):
        for name in ['seedance-prompt','seedance-prompt-short','seedance-motion']:
            text=(ROOT/'skills'/name/'SKILL.md').read_text()
            self.assertIn('timing-policy.md',text)
            self.assertNotIn('no absolute seconds inside a block on Seedance 2.5',text)

    def test_frozen_responder_has_current_parameter_evidence(self):
        snapshot=eval_run.freeze_repository(ROOT)
        self.assertEqual(snapshot.files['SEEDANCE_2.5_数据覆盖表.md'].role,'responder')
        self.assertIn('references/timing-policy.md',snapshot.files)

    def test_parameter_mutation_is_rejected_instead_of_auto_repair(self):
        manifest=json.loads((ROOT/'evals/source-manifest.json').read_text())
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            for name in ['evals/source-manifest.json', *(x['path'] for x in manifest['sources'])]:
                target=root/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/name,target)
            overlay=root/'SEEDANCE_2.5_数据覆盖表.md'
            overlay.write_text(overlay.read_text()+'\nCorrupted duration claim.\n')
            with self.assertRaisesRegex(eval_run.HarnessError,'source digest does not match manifest'):
                eval_run.freeze_repository(root,enforce_evaluator_identity=False)

    def test_missing_installed_document_is_reported(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);p=root/'README.md';p.write_text('[evidence](docs/missing.md)')
            errors,count=link_errors(root,[p])
            self.assertEqual(count,1)
            self.assertEqual(len(errors),1)

if __name__=='__main__':unittest.main()
