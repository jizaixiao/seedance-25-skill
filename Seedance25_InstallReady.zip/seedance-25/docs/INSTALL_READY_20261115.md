# 安装就绪修订说明 · 2026-11-15

本次修订保留原有 1 个主技能、28 个子技能及镜头增强模块。

## 修订内容

- 补齐点号文件和两份工作流，不依赖恢复脚本。
- 统一连续镜头、动作数量、镜头数量和连续性锁定规则，旧经验不再作为硬性模型限制。
- 预筛改为结合上下文判断，保留正常题材、人物年龄、台词和参考职责。
- 清理不兼容的顶层元数据字段，保留版本、作者和来源信息。
- 旧版验收长日志不再冒充本次测试记录。

## 本地安装

将完整 ZIP 解压，进入 seedance-25 目录。电脑需 CPython 3.11–3.13。
不必运行恢复脚本，不必设置 API Key；写文字方案不需要调用模型 API。

Codex 用户目录安装：

```bash
python scripts/install_codex_skill.py --client codex --scope user
```

Claude Code 用户目录安装：

```bash
python scripts/install_codex_skill.py --client claude-code --scope user
```

自定义位置（参数是技能目录的父目录）：

```bash
python scripts/install_codex_skill.py --dest /absolute/path/to/skills
```

已有同名技能时，安装器会保留已有内容并拒绝覆盖；确认要替换后，在同一命令末尾添加 `--force`。
查看安装状态请用同样的目标参数运行 `python scripts/install_doctor.py`。
安装后按客户端的技能加载方式刷新；压缩包本身不会使任意聊天客户端自动安装技能。

在 ChatGPT 中使用：电脑端若提供技能导入入口，可导入本包；若没有，可上传本包并要求读取根 SKILL.md 及相应引用，仅作为本次任务参考。Android 聊天上传文件不等于安装到所有客户端。

## 发布校验

维护者执行完整离线检查前，按 docs/VALIDATION.md 安装锁定的校验依赖。
普通文字方案和安装器不依赖这些维护者工具链。

```bash
python scripts/validate_repo.py --release
python scripts/release_check.py
python scripts/eval_run.py --limit 1
```

最后一条只检查评测计划，不调用付费模型、不生成视频，也不证明生成成功率。
平台参数继续按入口核验，方舟参数不自动适用于即梦。原第三方镜头设计师的授权范围保持原样。
