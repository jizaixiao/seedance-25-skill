# Revision audit — 2026-11-15

> Historical input: preserved for traceability, not current 2.5 platform authority. Superseded by [R2 audit](REVISION_R2_2026-11-15.md).

## Scope
This is a **conservative maintenance revision** of the user-supplied Seedance 2.5 SkillOS v6.7.0 archive. It is **not** an official ByteDance release or a live verification of model/API claims. Original archive remains untouched.

## Changes
1. Fixed the validator's stale `seedance-20` parent expectation to `seedance-25`, matching all 28 child skills.
2. Restored the missing `.github/workflows/validate-skills.yml` CI entry point.
3. Included the Chinese Seedance 2.5 data overlay and this audit note in the explicit installer payload.
4. Fixed a source-inventory filename typo and a logically impossible platform-matrix sentence.
5. Flagged duplicated API model IDs rather than inventing replacement IDs.
6. Reconciled prompt/motion timing guidance: shot order and behavioral beats are the safe default; precise integer-second timestamps are an **unverified surface-dependent experiment**. Internal beat sheets are not guaranteed prompt controls.
7. Added explicit warnings about conflicting, unverified platform facts, while preserving the user's original overlay values as historical input.
8. Added `evals/revision-file-hashes.json` for this revision. The older `evals/source-manifest.json` remains unchanged as historical evidence and must **not** be presented as a passing freeze manifest.

## Unresolved / not verified
- The original source-manifest hash mismatches remain historical integrity issues; hashes were not silently rewritten.
- Some archived official-source claims refer to mirror snapshots or inaccessible pages; current Seedance capabilities, timestamp behavior, pricing, IDs, region and access require independent live verification.
- The 4–30 s / 30–180 s claims in the Chinese overlay may describe different surfaces or modes and are not verified here.
- Running the static validator does not establish real-world generation quality or model ranking.

## User-specific budget note
For the user's personal planning only: 480P trial ≈ RMB 0.5/s and 720P output ≈ RMB 0.9/s; monthly total AI-learning cap RMB 600 including ChatGPT Plus USD 20. These are user-provided inputs, **not platform API prices**.

## Recommended operational flow
Read root `SKILL.md` → route only needed subskills → identify active product surface and verify live constraints → director read → shot table and continuity locks → compile compact prompt → preflight safety/rights and consistency → trial short 480P shots → inspect failure evidence → change one variable → commit selected 720P outputs. Avoid unnecessary paid reruns.
