<picture>
  <source media="(prefers-color-scheme: dark)" srcset="../assets/hero-dark.svg">
  <source media="(prefers-color-scheme: light)" srcset="../assets/hero-light.svg">
  <img alt="Seedance 2.5 Skill OS 마스트헤드. 프레임을 붙잡지 말고, 모델을 연출하세요." src="../assets/hero-dark.svg" width="100%">
</picture>

# Seedance 2.5 Skill OS · 한국어

떠오른 장면을 바로 제출할 수 있는 연출 프롬프트로 만듭니다. 이 문서는 v6.7.0 한국어 페이지입니다. 영어 페이지를 번역한 것이 아니라, 쇼츠와 릴스를 만드는 크리에이터, 광고 대행사, 웹드라마와 뮤직비디오 팀이 읽는 순서대로 다시 구성했습니다. 영상 생성과 비용은 사용하는 서비스에서 발생하고, 이 스킬은 프롬프트를 제대로 쓰는 일만 맡습니다.

**언어:** [English](../README.md) · [中文](README.zh.md) · [日本語](README.ja.md) · 한국어(이 페이지) · [Español](README.es.md) · [Русский](README.ru.md)

5분 빠른 시작: [한국어 빠른 시작](QUICKSTART.ko.md)

## 빠른 시작

1. 저장소를 받습니다. git이 없으면 저장소 페이지의 **Code → Download ZIP**을 풀어도 됩니다.

   ```bash
   git clone https://github.com/Emily2040/seedance-2.0.git
   cd seedance-2.5
   ```

2. 그 폴더에서 클라이언트 하나를 골라 설치합니다. 루트 스킬 하나만 설치하면 하위 스킬은 함께 따라옵니다.

   ```bash
   # Codex
   python scripts/install_codex_skill.py --client codex --scope user

   # Claude Code
   python scripts/install_codex_skill.py --client claude-code --scope user
   ```

3. 클라이언트를 다시 시작하고 `seedance-25`을 선택한 뒤, 한국어로 장면을 설명하세요.

> [!TIP]
> 설치 스크립트는 파일을 복사할 뿐 네트워크에 접속하거나 무엇을 업로드하지 않습니다. 기존 설치를 교체할 때만 `--force`를 쓰고, 먼저 로컬 수정 사항을 따로 보관하세요. 자세한 내용은 [한국어 빠른 시작](QUICKSTART.ko.md#1-루트-스킬-하나-설치하기)에 있습니다.

## 첫 프롬프트

설치가 끝나면 무슨 일이 일어나는지, 무엇을 고정할지 그대로 말하면 됩니다.

> seedance-25을 써 줘. 포장마차에서 주인이 말없이 어묵 국물 한 컵을 손님 앞으로 밀어 준다. 카메라 고정, 음악 없음. 프롬프트만 줘.

한 가지 가능한 초안입니다(생성하지 않은 예시).

```text
포장마차 안, 고정 미디엄 숏.
주인이 말없이 어묵 국물 한 컵을 손님 앞으로 밀어 준다.
김이 올라와 손님의 안경을 잠깐 흐리고, 손님이 안경을 벗는다.
백열등 하나가 두 사람을 비춘다.
소리: 국물 끓는 소리, 비닐 천막에 떨어지는 빗소리. 대사 없음, 음악 없음.
마지막 2초는 안경을 내려놓은 손에서 멈춘다.
```

**의도:** 동작 하나, 눈에 보이는 끝점, 고정 카메라, 분명하게 정한 소리. "정"이라는 말은 쓰지 않았습니다. 국물을 밀어 주는 손, 김에 흐려지는 안경, 안경을 벗는 동작이 대신 보여 줍니다. 이것은 연출 의도이지 검증된 결과가 아닙니다. 길이와 화면 비율은 서비스의 설정 칸에 넣습니다.

## 상황별 안내

| 지금 가진 것 | 먼저 열기 | 받는 것 |
|---|---|---|
| 막연한 아이디어 | [`seedance-interview-short`](../skills/seedance-interview-short/SKILL.md) | 짧은 브리프와 첫 초안, 또는 진행에 꼭 필요한 질문 하나 |
| 이미 정리된 장면 | [`seedance-prompt`](../skills/seedance-prompt/SKILL.md) | 바로 제출할 수 있는 프롬프트 |
| 최대한 짧게 | [`seedance-prompt-short`](../skills/seedance-prompt-short/SKILL.md) | 영어 30~100단어 또는 같은 분량의 한국어 압축본 |
| 여러 클립으로 이어지는 이야기 | [`seedance-sequence`](../skills/seedance-sequence/SKILL.md) | 이야기 뼈대, 연속성 장부, 구간 지도, 첫 클립의 계약과 프롬프트 |
| 승인한 클립의 다음 부분 | [`seedance-continuation`](../skills/seedance-continuation/SKILL.md) | 실제 끝 장면에서 이어지는 프롬프트 |
| 이미지, 영상, 오디오 참조 | [참조 자료 작업 흐름](../references/reference-workflow.md) | 자료마다 하나의 역할과, 넘어오면 안 되는 요소 |
| 첫 프레임과 마지막 프레임 | [첫·마지막 프레임 안내](../references/first-last-frame-guide.md) | 양 끝을 고정한 연속 전환 |
| 결과가 조건에 안 맞음 | [`seedance-troubleshoot`](../skills/seedance-troubleshoot/SKILL.md) | 원인 진단과 한 곳만 바꾼 수정안 |
| 실존 인물, 캐릭터, 음원, 브랜드 | [`seedance-copyright`](../skills/seedance-copyright/SKILL.md) | 창작 기능을 유지한 안전한 대안 |
| 한국어 예시와 용어 | [`seedance-examples-ko`](../skills/seedance-examples-ko/SKILL.md), [한국어 연출 용어](../references/vocab/ko.md) | 카메라, 조명, 재질, 소리의 한국어 표현 |

## 실존 인물, 브랜드, 음원

> [!IMPORTANT]
> 아이돌이나 배우의 얼굴, 목소리, 유명 음원, 브랜드 로고는 다른 언어로 바꿔 써도 해결되지 않습니다. 창작 기능은 남기고 오리지널 인물, 오리지널 세계, 사용 허가를 받은 참조 자료, 또는 후반 작업 대안으로 바꿉니다.

이 작업은 [`seedance-copyright`](../skills/seedance-copyright/SKILL.md)가 맡습니다. 문제 없는 내용이 과도하게 차단될 때는 [`seedance-filter`](../skills/seedance-filter/SKILL.md)가 제작 맥락을 분명히 밝히는 방식으로 고칩니다. 의도를 숨기는 방식은 쓰지 않습니다.

## 한국어 프롬프트 원칙

1. **참조 태그는 그대로 둡니다.** `@Image1`, `@Video1`, `@Audio1`을 번역하지 않고, `@이미지1` 같은 표기도 만들지 않습니다.
2. **대사의 말투는 인물과 관계가 정합니다.** 안내문이 합니다체라고 해서 대사를 고치지 않습니다. 합니다체, 해요체, 반말은 각각 다른 인물을 만듭니다. [한국어 연출 용어의 말투 항목](../references/vocab/ko.md#speech-level-말투)을 참고하세요.
3. **"감성적인", "분위기 있는", "영화 같은"으로 끝내지 않습니다.** 카메라, 조명, 재질, 공기, 소리로 풀어 씁니다.
4. **한 클립에 동작 하나, 끝점 하나.** 동작이 둘이면 클립도 둘입니다.
5. **자막은 편집에서 넣습니다.** 예능식 자막과 문구는 영상 생성에 맡기지 않습니다. 모델이 만든 글자는 믿을 수 없습니다.
6. **인물 고정, 의상, 공간 구조, 동작의 끝점, 카메라 움직임을 먼저 정하고** 그다음에 조명과 소리를 씁니다.

## 연속 클립

긴 이야기는 한 번에 쓰지 않습니다. 첫 클립을 생성하고 실제 끝 장면을 확인한 뒤 다음 클립을 씁니다. 모델이 계획한 자리에서 멈춘다는 보장이 없기 때문입니다.

```text
이야기의 최종 목표: [마지막에 도달해야 하는 상태]
승인된 사실: [이전 영상에서 실제로 일어난 일]
이번 클립만: [이번에 보여줄 하나의 시각적 작업]
아직 보여주지 않을 것: [뒤 클립에 남겨둘 내용]
참조: @Image1은 인물 고정, @Video1은 카메라만, @Audio1은 템포만
프롬프트: [한 가지 동작 + 한 가지 카메라 + 실제 조명 + 소리]
```

## 한국적 정서를 화면으로

"한", "정", "여백의 미" 같은 말은 지우지 말고, 모델이 찍을 수 있는 물리적 요소로 바꿔 씁니다. 아래는 [한국어 연출 용어](../references/vocab/ko.md#aesthetic-registers-미학)에 적힌 몇 가지 가능성입니다. 정의가 아니라 작성자가 제안한 예입니다.

| 정서 | 화면으로 옮기는 한 가지 방법 |
|---|---|
| 한 | 움직임을 멈춘 인물, 긴 그림자, 식은 밥상, 빗소리만 |
| 정 | 말없이 반찬을 옮겨 주는 손, 어깨에 걸쳐 주는 외투 |
| 여백의 미 | 대칭 구도, 화면 대부분이 빈 벽, 인물은 구석에 작게 |
| 신명 | 북 장단에 맞춘 발 구름, 원을 그리며 도는 군무 |

## 자주 묻는 질문

**Seedance 2.5가 나왔는데 이 스킬을 써도 되나요?** 이 스킬은 Seedance 2.5용입니다. 바이트댄스 공식 페이지는 2.5를 별도의 새 모델 라인으로 확인했고 Dreamina에서 제공 중입니다. 여기 있는 길이, 참조 개수, 해상도, 모델 ID는 모두 2.5 수치이며 2.5에 그대로 적용할 수 없습니다. 연출 방법과 참조 역할, 연속성 규칙은 그대로 쓸 수 있습니다. [플랫폼 상태](../references/api-status.md)를 확인하세요.

**설치했는데 클라이언트에 안 보입니다.** 먼저 클라이언트를 다시 시작하세요. 그다음 같은 설치 위치로 `python scripts/install_doctor.py --client codex --scope user --json`을 실행해 파일이 일치하는지 확인합니다. doctor는 파일이 있다는 것만 증명하고, 클라이언트가 어느 사본을 불러오는지는 알려 주지 않습니다.

**클립 하나에 장면을 몇 개까지 넣을 수 있나요?** 공식 상한은 이 저장소에서 찾지 못했습니다. 장면이 늘수록 각 장면에 쓸 수 있는 초가 줄어듭니다. 동작 하나를 제대로 찍는 것부터 시작하고, [멀티숏 문법](../references/multishot-grammar.md)을 참고하세요.

## 검토 상태

이 문서는 AI를 활용한 초안이며, 한국어와 영상 제작 용어에 대한 독립적인 검토는 아직 받지 않았습니다. 예시 영상은 생성하지 않았습니다. 안내문은 합니다체로 통일했습니다. [지원 범위와 검토 기록](LANGUAGE_COVERAGE.md)을 참고하세요.
