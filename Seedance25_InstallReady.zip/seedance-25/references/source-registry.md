# Source Registry

last_verified: 2026-11-15
review_scope: partial

This revision reread official 2.5 launch, Ark tutorial, API, model list and prompt guide. Only claims explicitly identified below are current-source claims. Other provider, pricing, installation and policy inventories remain historical; no authenticated account or generation test was run. `review_scope: partial` intentionally retains the review warning.

| Source | Evidence label | Verified subject | Boundary |
|---|---|---|---|
| [Seed official 2.5 launch](https://seed.bytedance.com/en/blog/one-take-creation-flexible-referencing-introducing-seedance-2-5) | confirmed | 2.5 line and broad reference/edit/extension capabilities | Launch examples are not success rates. |
| [Ark 2.5 tutorial](https://console.volcengine.com/ark/region:cn-beijing/docs/seedance-2-5) | confirmed | Task classification, input roles and locked parameters | Account access is not tested. |
| [Create task API](https://docs.volcengine.com/docs/ark/create-video-generation-task-api?lang=zh) | confirmed | Exact request-field restrictions for the standard model | Recheck model-support list before implementation. |
| [Model list](https://console.volcengine.com/ark/region:cn-beijing/docs/model-list) | confirmed | Standard model identity and output options | Never assign one ID to several variants. |
| [2.5 prompt guide](https://console.volcengine.com/ark/region:cn-beijing/docs/seedance-2-5-prompt-guide) | confirmed | Second-level timestamp direction and timestamp-scoped editing | No deterministic or frame-accurate guarantee. |
| Active account, future flash opening, prices and UI credits | volatile | No live account test | Recheck at use time; no fixed quotation retained. |
| BytePlus, fal and [Runway](https://docs.dev.runwayml.com/guides/models/) 2.5 operations | unverified | No current operation verification in this revision | Do not relabel a 2.0 route. |
| Prior [arXiv model card](https://arxiv.org/abs/2604.14148) and mirror notes | unverified | Historical 2.0 evidence | Not 2.5 capability or performance proof. |
| Community / field examples | field-observed | Craft suggestions only | Not current model facts or measured success rates. |
| Director methods, density ladder and compact-prompt defaults | internal | Authored planning heuristics | Test against actual returned clips. |

## Evidence Labels

- `confirmed`: visible in a primary source on the stated date, within its exact scope.
- `volatile`: changeable operational facts; recheck before using.
- `field-observed`: source-reported practitioner observations, not independently reproduced here.
- `unverified`: insufficient current direct evidence.
- `internal`: package-authored workflow advice.

## Historical inventory

The [dated source inventory](../data/sources.seedance-2026-05-30.json), [mirror notes](../docs/EVIDENCE_NOTES_2026-09-26.md), [old revision note](../docs/REVISION_AUDIT_2026-11-15.md) and docs/history preserve earlier inputs. Their model labels and claims may have been corrupted by the earlier version conversion. They are retired as authorities for 2.5. Current claims are enumerated in [the 2.5 table](../SEEDANCE_2.5_数据覆盖表.md). Never update old retrieval dates merely to satisfy freshness.

## Client skill discovery paths — historical packaging record

The 2026-08-01 client-path review is preserved as unverified historical installation evidence, not a new review or a Seedance capability claim. See [agent compatibility](agent-compatibility.md). Its primary locators were:

- https://antigravity.google/docs/cli/plugins
- https://codelabs.developers.google.com/getting-started-with-antigravity-skills
- https://hermes-agent.nousresearch.com/docs/user-guide/features/skills

Recheck these client-specific sources before changing native discovery paths; successful local payload tests do not prove that a host loads the directory.
