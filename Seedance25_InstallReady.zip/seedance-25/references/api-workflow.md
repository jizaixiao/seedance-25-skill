# API Workflow

last_verified: 2026-11-15

Use this reference for Seedance 2.5 operational planning on Volcengine, BytePlus, Runway, fal, provider/router surfaces, or wrappers. It is not a static API contract. Always recheck the active provider docs or console before implementation.

Reviewed 2026-11-15: the Ark standard 2.5 profile is confirmed by public documentation. Current access and all other providers remain surface-specific. Historical helper examples are explicitly identified below; they are not 2.5 execution routes.

## Surface Gate

| Surface | Use when | Must recheck |
|---|---|---|
| Volcengine Ark | China-facing official Ark workflows, model IDs, task lifecycle, first/last-frame roles, `return_last_frame`, web-search tools, and virtual portrait assets. | model ID, region, entitlement, schema, pricing, duration, resolution, face/reference policy |
| BytePlus ModelArk | International BytePlus docs or console workflows. | JS-rendered pricing/model pages, account access, region, exact model ID, upload/file rules |
| Runway | Runway workflow only after verifying its exact current 2.5 operation; older seedance2 examples are not proof. | duration, ratios, plan, region, SDK field support, audio-reference combination rules |
| Provider/router APIs | EvoLink, OpenRouter, Kie.ai, PiAPI, LaoZhang, Runware, ModelsLab, AI/ML API, MuAPI, SeeGen, Segmind, or similar surfaces. | base URL, model ID, task endpoint, polling endpoint, callback/webhook support, billing unit, file hosting, reference schema, face policy, output URL lifetime, rights terms |
| Atlas Cloud | Historical 2.0 helper `scripts/atlas_seedance_generate.py`; not a verified 2.5 executor. | live model catalog and schema, account access, price, duration, resolution, ratio, output lifetime, rights terms |
| China-facing official surfaces | ByteDance Seed, Volcengine Ark, BytePlus ModelArk, Doubao, Jimeng/Jianying, CapCut/Jianying. | language/region, account tier, enterprise or individual access, identity verification, portrait/virtual-avatar flow, console entitlement, exact docs date |
| Wrapper APIs | Fast prototyping through a third-party provider. | whether names, prices, moderation, duration, or face support are wrapper-specific |

## Async Task Lifecycle

1. Create the task with source-dated model ID, prompt, duration, ratio/size, resolution, and reference files.
2. Store task ID, provider, request date, model ID, and prompt version.
3. Poll or use SDK wait helpers until completed or failed.
4. Retrieve output URL(s), optional last frame, logs/errors, and moderation/failure reason when provided.
5. Save output plus metadata for repeatability.
6. Cancel, delete, or list tasks only through the active provider's current docs.

## Request Checklist

- Prompt says one visible beat, one camera move, physical light, sound intent, and constraints.
- Mode is explicit: T2V, I2V, V2V, R2V, FLF2V, edit, or extend.
- Reference roles are explicit and legal: first frame, last frame, identity, product, motion, camera, timing, audio, or style.
- Audio references are paired with a text prompt and a valid image/video reference when the surface requires that combination.
- First/last-frame requests do not silently mix incompatible video/audio reference modes unless the active docs allow it.
- Real-person, face, portrait, and voice inputs have authorization and surface support.
- Pricing, duration, resolution, region, quotas, and model IDs have a verification date.

## Provider Notes

Use [the current evidence table](../SEEDANCE_2.5_数据覆盖表.md) for Ark. Do not reuse or rename old BytePlus, Runway or router IDs.

### Ark 2.5 task locks

| Operation | Required handling |
|---|---|
| T2V / semantic reference | Choose supported duration and ratio; pure audio reference is permitted on this Ark 2.5 profile. |
| First frame / first-last frame | Use first_frame / last_frame image roles and ratio=adaptive. |
| Edit | Include reference_video, use ratio=adaptive and duration=-1; name the edit and preserved layers. |
| Extend | Include reference_video, use ratio=adaptive; specify source and direction. Verify duration semantics instead of assuming it is final combined length. |

When supported, use omni_reference_task_type to make reference/edit/extend intent explicit; mismatched prompt intent can still cause asynchronous errors. Timestamp guidance follows [timing-policy](timing-policy.md).

### Atlas Cloud executable path

The optional Atlas Cloud helper remains a historical **2.0** integration, not a verified 2.5 executor. It is a source-checkout tool, excluded from the offline installed-skill payload. Its fixed model and request fields follow the [provider's T2V schema](https://www.atlascloud.ai/docs/more-models/bytedance/seedance-2.0-text-to-video/generateVideo); polling follows the [prediction guide](https://www.atlascloud.ai/docs/predictions). Documentation was reviewed 2026-09-07; account access, live generation, pricing and output quality were not tested. Recheck those before production use. These are Atlas-specific fields, not an official ByteDance API contract.

Preview the request without reading credentials or opening the network (also the default without `--dry-run`):

```bash
python scripts/atlas_seedance_generate.py \
  --prompt "Locked medium shot: one vendor closes her paper fan and places it beside a blue cup. Hold the final arrangement." \
  --duration 5 --resolution 720p --ratio 16:9 --dry-run
```

After explicit authorization for the request and provider cost, supply `ATLASCLOUD_API_KEY` through the environment. Submit once and poll with bounded GET requests:

```bash
python scripts/atlas_seedance_generate.py \
  --prompt-file prompt.md --duration 5 --resolution 720p --ratio 16:9 \
  --live --wait --max-polls 120 --poll-interval 5
```

The helper prints the validated prediction ID before waiting. To resume an existing job without another generation POST:

```bash
python scripts/atlas_seedance_generate.py --prediction-id YOUR_PREDICTION_ID --live --wait
```

The helper never automatically retries the generation POST. A failure after submission is ambiguous and must be reconciled from provider history before another paid create. Only prediction GET requests are repeated, at most 120 polls. `--timeout` bounds socket operations and the response read deadline; it is not a total generation-time or currency ceiling. Output URLs are printed as data and never downloaded. With `--wait`, stdout can contain an initial JSON record followed by a completed record.

Transport uses Python's TLS verification and a fixed Atlas host; it does not follow redirects or load curl/proxy configuration. IDs, status, model echoes, response size and strict JSON are checked. Errors omit remote bodies and credentials. The local prompt input cap is 64 KiB; this is a helper safeguard, not a model capability claim. Validation is offline with mocked responses; the helper is not a generation-quality benchmark.

Chinese-language search results need classification before use. Official ByteDance/Volcengine/BytePlus/Doubao/Jimeng/Jianying pages can support China-facing surface guidance. Hosted workflows, Chinese blogs, pricing comparisons, and business-partner news can provide context, but they are not public API contracts unless they link to provider-owned API docs.

BytePlus pages can be JavaScript-rendered. Do not infer live pricing or model IDs from incomplete static fetches.

## Error and Risk Playbook

| Symptom | Likely cause | First repair |
|---|---|---|
| 403 or unavailable model | region, plan, entitlement, vendor licensing, or provider gate | check surface-specific access docs and account console |
| audio-only request fails | wrong line, role, format or surface-specific pairing rule | check current operation; Ark 2.5 permits pure audio references, so do not force an image |
| first/last frame rejected | incompatible mode mix or wrong role fields | use provider's first/last-frame field names and remove video/audio refs if required |
| face/portrait upload blocked | real-person policy, verification, or asset-library requirement | use authorized virtual portrait path or original character rewrite |
| output drifts after extension | weak last-frame continuity or too many changed variables | use returned last frame as next first frame and change one variable |
| price estimate wrong | stale pricing page or wrapper-specific billing | recheck provider pricing page/console before quoting |

## Production Readiness

Keep a run ledger with: provider, model ID, prompt, mode, references, duration, resolution, generated audio flag, task ID, output URL, last frame, verification date, and failure notes. This makes prompt repair possible and prevents stale source claims from leaking into user-facing guidance.
