# Seedance 2.5 timing policy

last_verified: 2026-11-15

Scope: official Ark Seedance 2.5 prompt guide, read on this date. Other surfaces require their own schema and model check.

1. Choose the shape first: one continuous performance uses one paragraph; editorial coverage uses numbered shots in event order, with explicit cuts. This is a workflow default, not a model restriction.
2. When timing matters, Seedance 2.5 supports one-second timeline guidance: continuous ranges, time points and relative durations. Avoid gaps, overlaps, conflicting clocks and repeated actions at subsecond frequencies. Keep the total timeline consistent with the generation setting. Timestamps are supported direction, not guaranteed frame-accurate execution.
3. For an audio-led clip, use one master clock. Anchor events to the audio; add a timeline only when it agrees with that clock.
4. For timestamp-scoped edits, name the input video, interval, change and preserved content. Use the active edit operation's locked duration and aspect rules; do not send ordinary generation settings unchanged.
5. Keep storyboard estimates separate from actual measured output. Exact delivery timing requires checking the returned clip and, where necessary, post editing.

Example (authored wording, not an observed take): `Shot 1, 0–4s: locked wide view; the vendor folds the paper fan. Cut. Shot 2, 4–8s: close view; she places it beside the blue cup. Hold the settled arrangement.` Set total duration to 8 seconds on an operation that supports it. A continuous-take version needs no shot labels.

Source: [official 2.5 prompt guide, “时间戳”](https://console.volcengine.com/ark/region:cn-beijing/docs/seedance-2-5-prompt-guide). The old 2.0 warning against timestamp syntax does not define 2.5 behavior.
