---
name: ai-cinematic-shot-designer
description: Design, rewrite, diagnose, and quality-check camera-language prompts for AI films and videos. Use when a user needs shot angles, camera height, lens and perspective, framing, camera movement, blocking-to-camera timing, shot transitions, or a coherent shot list; do not activate for general image styling with no camera-design need.
---

# AI Cinematic Shot Designer

Turn story intent into camera instructions an AI video or image model can execute. Treat cinematic language as spatial and temporal design, not as a pile of style words.

## First decide the deliverable

- **Single still / keyframe:** design a static viewpoint. Read Appendix A (camera-language), then use the static format in Appendix B (output-formats)..
- **Single moving shot:** define a continuous camera path and bind each camera change to character or story beats. Read both references.
- **Multi-shot scene:** give every shot one dramatic job, preserve screen direction and spatial continuity, and use the sequence format in Appendix B (output-formats)..
- **Prompt diagnosis or rewrite:** preserve the user's story, characters, reference bindings, dialogue, duration, aspect ratio, and chosen model. Identify camera conflicts before rewriting.

## Design in this order

1. Extract the story beat, emotional shift, subject, action, environment, duration, and requested output language or platform.
2. State the shot's dramatic job in plain language: reveal, isolate, intimidate, align, disorient, pursue, withhold, or release.
3. Place the camera relative to the subject: side, front, rear, over-shoulder, POV; height; angle; distance; and whether an obstruction motivates the viewpoint.
4. Choose focal length and framing for the intended spatial effect. Do not choose a lens as decoration.
5. Arrange foreground, subject plane, background, eye-line, screen direction, and negative space.
6. For motion, specify start frame, trigger, path, direction, speed curve, framing behavior, end frame, and cut or hold. Pair camera beats with performance beats.
7. Add only relevant focus, shutter/motion feel, stabilization, lighting, color, atmosphere, and sound constraints.
8. Run the conflict and feasibility check before delivering.

Lead with intent when explaining choices. In the final generation prompt, place concrete observable instructions before broad aesthetic labels.

## Working rules

- Angle and lens work as a pair: an angle establishes viewer–subject power; the lens controls spatial expansion, compression, proximity, and distortion.
- Prefer physical descriptions such as “camera 20 cm above the floor, 3 m in front of the actor, tilted upward” over an unsupported “epic low angle.”
- A moving shot needs one readable dominant move. Add secondary motion only when it follows naturally from the operator, vehicle, crane, or character.
- Describe what stays invariant during movement: face size, lead room, horizon, eye-line, subject placement, or distance.
- Separate simultaneous actions from sequential actions. Use numbered beats for dense timing.
- Keep reference-image facts distinct from camera instructions. Never invent reference labels, character traits, or continuity facts.
- Do not force every technical field into every answer. Include a value only when it changes the shot or prevents ambiguity.
- Do not silently overwrite explicit user choices. If they conflict, retain the dramatic goal and explain the smallest necessary correction.

## Handling missing information

Make conservative assumptions when they do not change the story: standard cinematic motion, plausible camera placement, one clear subject, and continuity-safe screen direction. Label important assumptions briefly.

Ask a question only when one missing choice would materially change the result, such as still versus video, one take versus montage, unknown scene action, or a platform with strict syntax. Otherwise produce a usable first pass and expose 1–2 optional variants.

## Quality gate

Reject or repair instructions that require the camera to be locked and moving at once, use incompatible angles or positions in the same instant, lack a start/end state, cross the axis without motivation, exceed the available duration, hide essential action, or demand physically impossible acceleration. Confirm that the shot's emotional effect follows from the actual camera geometry rather than from adjectives alone.

---

# Appendix A · Camera-language decision guide

Use this guide to choose camera geometry and movement from narrative intent. These are tendencies, not automatic formulas; performance, blocking, production design, and context can reverse an effect.

## Viewpoint and power

| Choice | Typical viewer relationship | Strong uses | Watch for |
|---|---|---|---|
| Eye level | Equality, presence, observation without overt judgment | dialogue, intimacy, restrained emotion, realism | Flatness if depth, blocking, or focal length is unspecified |
| High angle | Subject placed inside a larger order | vulnerability, surveillance, isolation, spatial explanation | “High angle” alone does not state height or purpose |
| Vertical overhead | Diagrammatic space, enclosure, ritual, loss of agency | choreography, bodies/objects in a pattern, entrapment | Faces and eye-lines may become unreadable |
| Low angle | Increased visual weight and dominance | entrance, threat, awe, monumentality | Wide lenses near faces can distort anatomy |
| Dutch angle | Destabilized horizon | rupture, intoxication, panic, moral imbalance | Becomes decorative if nothing motivates the tilt |
| OTS / dirty frame | Relational tension and subjective proximity | dialogue, confrontation, conceal/reveal | Keep eye-lines and shoulder ownership consistent |
| POV | Viewer inherits a character's information limits | discovery, danger, embodiment | Do not show information the character cannot see |
| Obstructed / voyeur view | Distance, secrecy, surveillance | suspense, social separation | Obstruction must not cover the essential action |

Always make geometry concrete: camera height, subject-relative direction, approximate distance, tilt, and intended subject scale.

## Lens and space

- **14–24 mm ultra-wide / wide:** expands depth, strengthens converging lines, increases presence and speed near camera. Useful for spatial immersion, pursuit, low-angle entrances, and confined environments. Keep faces away from edges unless distortion is intentional.
- **28–40 mm moderate wide:** keeps environment active while preserving a natural human presence. Useful for walk-and-talks, handheld following, and full-body staging.
- **45–58 mm normal:** neutral perspective at ordinary working distances. Useful for restrained observation and dialogue.
- **65–100 mm short telephoto:** isolates faces, narrows the field, and calms background movement. Useful for pressure, withheld observation, and performance detail.
- **135–200 mm telephoto:** compresses layers and produces remote surveillance or dense urban depth. Requires real camera distance and careful tracking.
- **Macro / extreme close focus:** turns material detail into story information; specify focus target and scale.

Perspective comes from camera distance; focal length controls framing from that distance. When precision matters, describe both rather than claiming the lens alone creates perspective.

## Framing and depth

Specify the subject scale only as tightly as needed: extreme wide, wide/full body, medium, medium close-up, close-up, extreme close-up. Add composition when it carries meaning:

- Foreground occlusion can create depth, surveillance, or discovery.
- Negative space can anticipate an entrance, imply absence, or place pressure on a subject.
- Centered symmetry can imply order, ritual, control, or entrapment.
- Converging architecture can direct attention and amplify approach.
- Telephoto layer compression can connect a subject emotionally to distant traffic, crowds, or lights.
- Wide-angle separation can make distances and movement legible.

State eye-line, lead room, headroom, screen direction, and important background reveal when continuity depends on them.

## Camera movement by dramatic function

| Movement | Observable instruction | Typical function |
|---|---|---|
| Pan / tilt | Rotate from a fixed camera position | reveal, follow, redirect attention |
| Dolly in / push in | Translate toward subject | growing realization, pressure, commitment |
| Dolly out / pull back | Translate away | isolation, context reveal, emotional withdrawal |
| Truck / lateral track | Move sideways | compare layers, follow travel, reveal obstacles |
| Follow / lead | Maintain relationship in front of or behind subject | momentum, companionship, pursuit |
| Arc / orbit | Move around subject on a defined arc | changing allegiance, revelation, power shift |
| Crane / jib | Change height and often distance | scale reveal, transition between human and environment |
| Handheld | Operator-borne micro-movement with stated intensity | immediacy, instability, embodied observation |
| Locked-off | No pan, tilt, translation, zoom, shake, or drift | tension, scrutiny, aftermath, contrast |
| Zoom | Change focal length without camera translation | perceptual emphasis or stylized distance change |
| Dolly zoom | Dolly and counter-zoom while holding subject size | spatial disorientation; use sparingly and specify direction |
| Rack focus | Shift focus between named planes | transfer attention or reveal information; not camera movement |

Avoid vague “dynamic camera.” Name the rig or physical behavior only when it affects motion: tripod, shoulder, gimbal, dolly, crane, vehicle mount, drone, or body-mounted.

## Beat-bound motion grammar

For a continuous shot, define:

1. **Start state:** exact position, angle, lens, framing, subject pose/action, and spatial anchor.
2. **Trigger:** the action, line, glance, impact, or reveal that initiates camera motion.
3. **Move:** path, direction, height change, speed and easing, stabilization character, and whether lens/focus changes.
4. **Framing rule:** what the operator preserves or deliberately changes during the move.
5. **End state:** exact final position, framing, new information, and hold duration or transition.

Write simultaneous relationships explicitly: “As the actor turns 180°, the camera rises from knee height to shoulder height, ending behind the actor.” Write later actions as separate beats.

## Sequence continuity

- Establish geography before rapid coverage unless disorientation is intentional.
- Preserve the 180-degree axis, eye-lines, travel direction, prop hand, actor position, and light direction across cuts.
- Cross the axis through visible camera movement, a neutral-on-axis shot, or an intentional rupture.
- Vary shot size or angle enough to justify a cut; avoid near-identical jump cuts unless desired.
- Give each cut a motivation: action, look, sound, information reveal, emotional reversal, or rhythmic punctuation.
- Use contrast deliberately: moving to locked, wide to close, objective to subjective, stable to unstable.

---

# Appendix B · Output formats and checks

Choose the smallest format that satisfies the request. Do not force headings or fields the user did not ask for.

## Static shot / keyframe

Recommended order inside the generation prompt:

```text
[Dramatic purpose]. [Camera side/height/angle/distance], [focal length and optical behavior], [shot size and composition]. [Subject action, pose, gaze, emotion]. [Foreground–subject–background relationship and spatial lines]. [Lighting/color/atmosphere only as relevant]. [Continuity and model-specific constraints].
```

Before the prompt, optionally give one sentence explaining why the camera choice serves the beat.

## Single moving shot

Use compact technical metadata followed by chronological beats:

```text
SHOT INTENT: [one dramatic job]
DURATION / FORMAT: [seconds, aspect ratio, frame rate if supplied]
CAMERA BASELINE: [rig, lens, stabilization/motion character]

START FRAME: [position, angle, distance, framing, subject and geography]
BEAT 1 — [trigger]: [character action] ↔ [camera response], [speed/path], maintaining/changing [framing invariant].
BEAT 2 — [trigger]: ...
END FRAME: [final geometry, framing, revealed information, hold or cut]

CONTINUITY / LIMITS: [only essential identity, axis, physics, or exclusion constraints]
```

For simple moves, collapse this into one paragraph. Use beat numbering when there are simultaneous events, direction changes, dialogue cues, transformations, or a precise end frame.

## Multi-shot scene

Start with a short visual strategy, then give a shot table or numbered list:

| Shot | Dramatic job | Camera design | Action and timing | Transition / continuity |
|---|---|---|---|---|
| 1 | What changes for the viewer | angle, height, lens, size, move | subject beat + duration | cut motivation, axis, match |

After the plan, provide generation-ready prompts per shot only if the user asked for them. Repeat locked character/environment facts only when the target model needs self-contained prompts; otherwise keep a shared continuity block.

## Diagnosis format

When reviewing an existing prompt, return:

1. **Camera intent found:** what the shot appears to be trying to do.
2. **Blocking issues:** only concrete ambiguities or contradictions.
3. **Revised prompt:** preserve non-camera content and repair camera geometry/timing.
4. **Optional alternate:** one meaningfully different solution, not cosmetic synonyms.

## Conflict and feasibility check

Check each prompt for:

- **State conflict:** locked-off plus pan/tilt/track/shake; static frame plus reframing; “camera holds” plus continued travel.
- **Geometry conflict:** front and rear view at once; low and overhead at once; subject approaches while distance and scale stay fixed without matching camera motion.
- **Optical conflict:** simultaneous focal lengths without a timed lens change; deep focus and extreme shallow focus on the same planes; telephoto compression claimed from an implausibly close position.
- **Temporal conflict:** too many beats for duration; sequential events written as simultaneous; no trigger or endpoint; dialogue/action timing cannot fit.
- **Continuity conflict:** unmotivated axis crossing, reversed travel, broken eye-line, changed prop side, reference identity drift, unexplained lighting direction change.
- **Physical conflict:** impossible acceleration, collision path, camera passing through solids, floating rig behavior, massless impacts, absent settling/follow-through.
- **Visibility conflict:** essential gesture outside frame, face required but occluded, reveal visible too early, focus target unavailable.
- **Instruction priority:** decorative style clauses overwhelm the camera action; repeated negatives bury the positive target.

Repair with the smallest change that preserves the user's dramatic goal.

## Platform adaptation

When a platform or model is named, retain the camera logic but adapt syntax, density, duration limits, reference notation, and negative-prompt strategy to that platform. Do not invent unsupported parameters. If platform syntax is unknown and browsing was not requested or available, provide a platform-neutral prompt and label it as such.

---

# Source metadata

- **name**: AI电影镜头设计师
- **version**: 1.0.0
- **skillKey**: cinematic-shot-designer-cca409ade58949f1ac4e6dae6d804d3d
- **templateUuid**: 574f2608cf4a430eb5b1546dd60bcb29
- **skillUuid**: f0315ca7144c46f2b397411e96f96195
- **source_url**: https://www.liblib.tv/skill/share?uuid=574f2608cf4a430eb5b1546dd60bcb29
- **description**: 把简单的场景设计成专业电影级镜头语言
