# Moderation Pre-Screen — contextual review before delivery

## Boundary

Assess the underlying request and the actual platform's rules. Topic words alone do not establish a content violation or prove that a platform will refuse a prompt. Historical observations from another model or surface are not current Seedance 2.5 restrictions. This heuristic screen is never a verdict about a platform.

Preserve benign settings, characters, ages, dialogue, reference tokens and story events. Do not remove a hospital, legal document, ordinary kitchen tool or other legitimate detail merely because it appears in the cue lists. If the request is prohibited, refuse or offer an allowed alternative; do not disguise the same content through omission, euphemism or a language change. Follow [seedance-filter](../skills/seedance-filter/SKILL.md).

## When it runs

Review before delivery on every route and after an actual rejection. Normal benign work needs no warning or rewrite note when nothing requires a change. Screening does not authorize a generation, upload, paid retry or provider switch.

## The cue classes

The language lists in `data/moderation-cues.json` are historical lexical review flags, not official blocked-word lists. Severity is a local triage rank, not an acceptance prediction. Three medium hits are not evidence of a platform rule.

| Class | Review question |
|---|---|
| Weapon | What action and context are actually requested? |
| Injury | Is the depiction allowed under the relevant rules? |
| Crime | Is this storytelling, analysis or assistance with wrongdoing? |
| Minor | What age and context are supplied, and does a real boundary depend on them? |
| Institution | Preserve benign medical, legal and police settings; a topic name is insufficient. |
| Substance | Assess the actual action and intended audience. |
| Horror | Distinguish ordinary fictional suspense from prohibited depictions. |
| Identity and symbols | Assess the actual identity, rights and use; do not assume authorization. |

## The method, in one pass

1. Read the scene and classify the underlying request before consulting word flags.
2. Keep a benign complete brief intact. Clarify an ambiguous phrase only when it materially changes interpretation.
3. Separate actual provider feedback, user reports and hypotheses. A lexical hit does not identify the cause of a rejection.
4. For a faithful wording clarification, preserve story, dialogue, references, timing and shot shape. If an edit changes any of these, offer it as an alternative unless already authorized. Do not silently age characters, replace a setting, remove a prop or rewrite dialogue.
5. Explain substantive changes briefly. Do not promise approval or acceptance, and do not submit synonym probes or attempts to evade safeguards.

## After a block

Read the actual error. Input rejection, output rejection, entitlement, asset constraints and malformed parameters may require different responses. If the reason is unavailable, say it is unknown. Review an appropriate authorized correction or an allowed creative alternative; follow [retake protocol](retake-protocol.md) before any submission.

## Offline lint boundary

`scripts/moderation_prescreen.py` matches words only. Default mode reports candidates for human or contextual review. Its opt-in `--fail-on-high` is a conservative editorial gate for the package's own examples; it neither rejects the user's scene nor predicts a provider decision. Do not treat a passing scan as content approval.
