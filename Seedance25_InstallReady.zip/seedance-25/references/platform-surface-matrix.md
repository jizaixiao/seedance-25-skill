# Platform Surface Matrix

last_verified: 2026-11-15

The model line, product surface, operation and entitlement are separate. No row grants access or establishes cross-provider field compatibility.

| Surface | Evidence status | Operational rule |
|---|---|---|
| ByteDance Seed 2.5 page / launch | confirmed model-level capability | Not an API schema or account test. |
| Volcengine Ark standard 2.5 | confirmed public docs; volatile access/pricing | Use the task-specific [evidence table](../SEEDANCE_2.5_数据覆盖表.md); recheck account and fields. |
| Jimeng / Doubao | confirmed mention in official launch; volatile UI | Recheck actual model selector, duration, resolution, credits and reference bindings. |
| BytePlus ModelArk | unverified current 2.5 profile | Resolve exact live model and operation; never derive dreamina IDs from doubao IDs. |
| Runway web/API/MCP | unverified current 2.5 profile | `seedance2` is not evidence of 2.5. Verify catalog, operation, SDK, entitlement and inputs. |
| fal / Atlas / Replicate / other routers | unverified current 2.5 profile | Existing 2.0 paths must not be renamed. Verify provider-owned documentation and billing. |
| ComfyUI / hosted workflows | unverified current 2.5 profile | A node label does not prove its underlying model or schema. |
| Community prompt corpora | field-observed historical patterns | Use for craft only, never for current limits. |

## API Shape Rule

Ark uses an asynchronous video task API: create, retain ID, poll/query, retrieve result. Do not submit video through a language-model chat request. Other providers need their own documented lifecycle.

## Surface-Specific Claims

Record source URL, verification date, exact model, operation, region/account constraints and unresolved fields. Withhold unknown numbers while continuing the creative draft. Rights and face/voice support require both authorization and active-surface support.

## V2V, R2V, and FLF2V Boundary

Distinguish semantic reference from editing and extension. On Ark, first/last-frame and source-video tasks lock parameters; use [api-workflow](api-workflow.md). A declared reference role never guarantees returned fidelity.
