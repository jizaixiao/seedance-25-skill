# API Status — Seedance 2.5

last_verified: 2026-11-15
review_scope: partial

Public official documentation was reread; no account entitlement, paid generation or returned adherence was tested. This is a documented capability snapshot, not an access or quality guarantee.

## Active profile

Use the row-level [parameter and evidence table](../SEEDANCE_2.5_数据覆盖表.md), [model-name map](model-name-map.md), [task workflow](api-workflow.md) and [timing policy](timing-policy.md). Numeric claims apply only to the exact surface and task. Current Ark 2.5 supports timestamp guidance; the 2.0 shot-order-only warning must not be attributed to 2.5.

## Status boundaries

- Ark standard 2.5 has public API documentation. Public examples do not prove this account's access, quotas, region, pricing or upload authorization.
- Flash has a scheduled-opening notice, not an observed successful call. Resolve exact ID and availability at use time.
- Jimeng and Doubao appear in the official 2.5 launch material. Their UI limits and credits are not the Ark contract.
- BytePlus, Runway, fal and all routers are unverified for current 2.5 operations in this revision. A 2.0 endpoint, catalog row or old screenshot must not be relabeled 2.5.
- Old prices, Mini/Fast/Pro mappings, overseas suspension reports and native-resolution generalizations are retired from current guidance. Do not use historical assertions to answer today's availability question.
- The older model card [arXiv 2604.14148](https://arxiv.org/abs/2604.14148) and old provider pages are historical 2.0 evidence, not 2.5 benchmarks.

## Known limits and observation boundary

Plan for possible identity drift, complex-contact errors, text inaccuracies, dialogue omissions and sync errors. These are review targets, not measured 2.5 failure rates. Same seed is not a guaranteed lock; do not send seed, frames, camera_fixed or flex merely because an older model accepted them. Check the active field's model-support list.

## Sources

- [2.5 official launch](https://seed.bytedance.com/en/blog/one-take-creation-flexible-referencing-introducing-seedance-2-5).
- [Ark 2.5 tutorial](https://console.volcengine.com/ark/region:cn-beijing/docs/seedance-2-5).
- [Ark request contract](https://docs.volcengine.com/docs/ark/create-video-generation-task-api?lang=zh).
- [Ark 2.5 prompting](https://console.volcengine.com/ark/region:cn-beijing/docs/seedance-2-5-prompt-guide).

For evidence grades and retired inventories, read [source-registry](source-registry.md).
