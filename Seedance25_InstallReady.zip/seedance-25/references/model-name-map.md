# Model Name Map

last_verified: 2026-11-15

This skill targets Seedance 2.5. Resolve the model line, surface, variant and operation separately. Never upgrade an old name or endpoint by string replacement.

| User wording / ID | Meaning | Action |
|---|---|---|
| Seedance 2.5 / seed2.5 / Seedance25 | Target video model line in this package | Use the 2.5 workflow; resolve the active surface before numeric settings. |
| Doubao Seedance 2.5 | Official Ark label | Use the source-dated Ark profile. |
| `doubao-seedance-2-5-260628` | Standard Ark 2.5 ID listed in official docs on the verification date | Use only on Ark after access/schema check; not a generic Fast, Mini or Pro ID. |
| Seedance 2.5 flash | Official announcement visible; stated opening 2026-11-15 14:00 Asia/Shanghai | Check time, model detail, account and exact ID before use. Do not treat a scheduled opening as tested access. |
| Seedance 2.5 Fast / Mini / Pro | Surface or variant label not mapped here | Keep the user's wording; do not invent a variant or reuse the standard ID. Ask which surface only if needed for implementation. |
| Seedance 2.0 / V2 / V2 Mini | Older or ambiguous model wording | Do not normalize to 2.5. Reuse craft only; verify that line's own limits. |
| `doubao-seedance-2-0-*` | 2.0 API family | Historical comparison only in this 2.5 package. |
| `seedance2` / fal `seedance-2.0` paths | Existing provider-specific older routes | Not proof of 2.5. Check the provider's exact operation before implementation. |
| BytePlus `dreamina-*` / router aliases | Surface-specific names | No prefix substitution from Ark; resolve live docs. |
| Seed / Doubao language models, Seedream | Different model families | Do not route to Seedance video parameters. |

For ambiguous Pro/Mini requests, continue the creative draft with the supplied name and withhold unsupported numeric settings. For translation-only work, preserve names and bindings; no forced model-selection interview.

Sources: [official model list](https://console.volcengine.com/ark/region:cn-beijing/docs/model-list), [2.5 tutorial and flash notice](https://console.volcengine.com/ark/region:cn-beijing/docs/seedance-2-5). See [parameter evidence](../SEEDANCE_2.5_数据覆盖表.md) and [surface matrix](platform-surface-matrix.md).
