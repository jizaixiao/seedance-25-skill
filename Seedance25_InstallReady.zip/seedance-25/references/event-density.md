# Event Density

Use this reference to decide how much story belongs in one generation.

## Density Rule

One generation should normally carry one visible beat with a changed endpoint. Long backstory, multiple locations, multiple major actions, dense dialogue, and future resolution belong in the sequence plan, not the current prompt.

## Beat Buckets

`already_happened`: do not replay.

`this_clip_only`: the current prompt may perform this.

`reserved_for_later`: do not show yet.

`do_not_show_yet`: excluded even if it explains motivation.

## Scope Firewall

Story context can inform motivation, performance, atmosphere, and pacing. It must not cause the current clip to perform future events, reveal future information, solve later problems, or skip physical handoff states.

## Official Density Warning

The current 2.5 prompt guide warns that sparse timed content can invite elaboration and overloaded intervals can omit content. Plan sufficient time for each essential beat. Older 2.0 troubleshooting examples are craft context, not 2.5 performance measurements. See [timing-policy](timing-policy.md).

This repository's planning number for that warning is the load score in [multishot-grammar](multishot-grammar.md): seconds per load point S = duration ÷ (beats + load), where a reaction shot or an insert counts half a beat. S of 3.0 or more is Safe, 2.5 to 3.0 is Stretch, under 2.5 is Ambitious and the split is the recommended spend. The thresholds are authored heuristics awaiting rendered calibration, not official limits. Shape comes first: a single continuous action in one scene is one paragraph and needs no score.

## Splitting Triggers

Split when a request asks for several completed actions, a journey with multiple locations, several turns of dialogue, complex physical contact, product proof plus hero packshot, a storyboard whose load score falls under 2.5, or a story longer than the verified active-surface duration.
