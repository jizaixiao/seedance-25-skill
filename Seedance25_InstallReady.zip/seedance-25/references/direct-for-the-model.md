# Direct for the Model — readable action and continuity

These are conditional craft heuristics drawn from historical examples, not verified Seedance 2.5 restrictions. Follow the user's chosen continuous take or storyboard, the current evidence table and [timing policy](timing-policy.md). Do not turn limited older observations into universal model behavior.

## 1. Translate intention into visible behavior

Use clear action, gesture, gaze and sound. A short feeling word may clarify performance when useful, but is not mandatory and cannot replace a visible carrier. Avoid ambiguous idioms when a literal description better preserves intent. Keep the [Director's Read](directors-read.md) labels inside the brief.

## 2. Action density, not a fixed action count

Choose one main dramatic job. Several ordered actions, coordinated performances and background activity can coexist in one continuous shot when readable. Do not freeze everyone else to simplify the main action. If an overloaded beat is unclear, simplify secondary detail, adjust pacing or offer coverage; do not automatically cut each action into a new shot.

## 3. Continuity locks where they matter

Preserve identity, reference tags, light direction, principal positions, eyelines, screen direction and prop ownership. State the relevant locks in the shared continuity block or shot table and repeat only the ones a self-contained prompt needs. A full lock line after every shot is optional. Reaction reverses are one coverage choice, not mandatory.

## 4. Props and contact

For fragile contact, name the hand, grip, contact point and final state only as needed. A grip change can stay in a continuous shot. Do not claim that motions under two seconds are guaranteed safe or that two grips require two shots. Review actual footage before concluding the action worked.

## 5. Geography and framing

Make important changes of position legible through staging, motivated camera movement, an explicit time transition or a justified cut. Crossing a room may remain inside the same shot. A close-up can reach a new detail through a stated tilt, track or focus change; if no movement can show it, offer another framing or cut.

## 6. Performance and sound

Preserve requested expression, dialogue, voice, rhythm and incidental activity. Several people can perform together when their ownership and timing are clear. Do not require every speaker to receive a separate shot. For audio-led work, use one master clock.

## 7. Intended mishaps and spectacle

If the story calls for an accident, describe the visible cause, response and settled result. Do not replace the accident with a deliberate action without explaining the creative change. Complex contact or spectacle may be uncertain; state that as a planning risk, not a universal prohibition.

## 8. Final pass

Check action order, visibility, geometry, reference roles, continuity, timing and sound. Preserve explicit one-take or fixed-shot choices. Offer a split only when it solves a concrete problem; label any substantive alternative and keep approved decisions intact. Apply [moderation review](moderation-prescreen.md) contextually and never infer a violation from a word alone.
