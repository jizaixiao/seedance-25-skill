# Capability Map — design into strengths, around limits

*Planning map for 2.5 workflows, not a measured ranking. Source-gated means the exact active model and operation must be checked in [the evidence table](../SEEDANCE_2.5_数据覆盖表.md); inherited field reports remain hypotheses until observed on 2.5.*

## Four layers, verified separately

A row below being marked [source-gated] answers one question, not four. Keep these apart, because provider documentation routinely establishes one and says nothing about the rest:

| Layer | The question it answers | What a source can prove |
|---|---|---|
| Model capability | can the model do this at all? | a model-level doc can describe a modality without saying which product exposes it |
| Surface access | does this surface, in this operation, expose it? | availability is per operation; a sibling operation on the same surface proves nothing |
| Request syntax | how is it expressed in the request? | an example demonstrates an authored form; it does not make that form universal |
| Returned adherence | did the output actually follow it? | only an observed take answers this, and one take is an observation, not a guarantee |

The practical rule: never promise a deliverable on the strength of a capability claim alone, and never treat a provider's example as evidence that the result will obey it. A returned take is evidence about that take. It is not proof of the model's internals, and not a promise about the next one.

The rows below are compressed for scanning, so a single `[source-gated]` label sits over several claims at different layers. Split the row before relying on it. The multi-shot row reads:

| Element | Layer | Actually established by |
|---|---|---|
| multi-shot in one call | model capability | current 2.5 primary sources; verify active operation |
| `Shot 1:/2:/3:` labels | request syntax | the official shot-order device (镜头1/2/3 in the Volcengine guide; `Shot 1` is the English equivalent), organizing content in event order; no source proves a universal parser, and the cut still has to be written in words, see [multishot-grammar](multishot-grammar.md) |
| timestamps inside the prompt | request syntax | 2.5 supports second-level direction; follow [timing-policy](timing-policy.md), not the old 2.0 ban |
| Tier choice | surface access | check the active endpoint; do not infer a Standard requirement |
| Duration and `auto` | surface access | only the active endpoint can establish supported values |
| load per beat and the Safe / Stretch / Ambitious ladder | heuristic | this repository's planning thresholds, to be calibrated by rendered takes; not a documented limit |

One row, four layers, and two different evidence grades. The provenance label on a row is the strongest claim in it, never a guarantee about every element — which is why the tier claims below carry their own `[field]` marker.

## Design INTO these

| Capability | Extraction move |
|---|---|
| Multi-shot in one call [source-gated] | numbered shots in event order with the cut written in words · one primary action and at most one camera move per shot · duration set as the surface parameter; optional coherent timestamp direction follows the timing policy · shot count placed on the load-per-beat ladder [heuristic] |
| Native synced audio [source-gated] | name specific sounds; dialogue as a natural quoted line on-screen; short lines; clean front face ref; prioritize the sound layer required by the brief; test dialogue and sync before adding layers |
| Role-separated references [source-gated] | per-asset role **+ exclusion** ("motion only, no appearance") |
| Motion transfer via @Video [source-gated/field] | donor clip for choreography/camera rhythm + identity @Image |
| Audio-as-clock via @Audio [field] | "cut on the beat of @Audio1; the turn lands on the drop" |
| First/last frame [source-gated] | lock endpoints; prompt initiate→travel→resolve; transformations & match-cuts |
| Literal camera verbs [source-gated] | one motivated move per shot |
| Physics [unverified hypothesis] | physical verbs & consequences, not pose adjectives |
| Slow motion [source-gated] | Standard tier [field]; on the single key action |
| Transformation [field] | endpoint states + the persisting carrier; hard cases → FLF decomposition |
| 2D/anime [field] | medium grammar: cel over painted bg, sakuga vs held frames, impact frames/speed lines/smears; no lens/DOF talk — full grammar in [2d-anime-grammar](2d-anime-grammar.md) |
| Formats and duration [surface-specific] | Choose the delivery ratio and a supported duration; use `auto` only when documented for that endpoint |
| Multilingual [source-gated/field] | zh anchors for texture/mood; keep reference tags exact |

## Design AROUND these

For connected generations, design around continuity drift by keeping each clip small, recording accepted observed state, preserving exact reference roles, and re-anchoring on schedule at the scene's chain-depth cap instead of waiting for visible drift. This is workflow guidance, not a deterministic platform guarantee.

Surface duration caps are active-surface facts, not universal Seedance facts; audio is not continuous across separate calls, so score in post when needed [source-gated] · on-screen text → post [source-gated] · prefer clear desired states while retaining useful exclusions [heuristic] · tiny detail (distant faces, hands, logos) degrades [field] · facial micro-acting weakest — stage emotion in body/staging, ration CUs [heuristic] · visible drift after repeated chained generations — re-anchor original refs [field] · character↔prop physics fragile in multi-person shots — keep contact simple or off-screen, use the three-tier action hierarchy [field] · Fast tier behavior is surface-specific [field] · seed support is operation-specific; do not assume Ark 2.5 accepts it.

## Current model facts

Use [the evidence table](../SEEDANCE_2.5_数据覆盖表.md). Older model cards and competitor comparisons do not establish 2.5 specifications.
