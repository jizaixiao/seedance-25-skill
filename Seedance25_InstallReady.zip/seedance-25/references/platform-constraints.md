# Platform Constraints

last_verified: 2026-11-15

Use the row-level [2.5 evidence table](../SEEDANCE_2.5_数据覆盖表.md) only within its stated Ark scope. It is not a universal platform contract. Historical values are retired, not current authority.

- Resolve surface, model ID, operation, date, account and region before implementation.
- Distinguish total generated duration, appended duration, source duration and editing interval.
- Apply task locks before optional settings; a target delivery ratio is not always an allowed API ratio value.
- Use current [timing-policy](timing-policy.md); supported second-level guidance is not frame-accurate certainty.
- Keep pricing, credits, entitlement and variant IDs volatile; recheck before quoting.
- Treat images, audio and video as role-bound references, not consent or deterministic controls.
- Use [api-status](api-status.md) for unresolved surfaces; do not transfer an Ark fact to Jimeng or a router.
