# Seedance 2.5 参数与证据表

核验日期：2026-11-15（北京时间）。以下已确认数字仅对应**火山方舟 Seedance 2.5 标准模型**；即梦、豆包、BytePlus、第三方入口须现场核对。公开文档核验不等于账户已开通或生成实测。

| 项目 | 当前结论 | 证据等级 / 来源 |
|---|---|---|
| 标准模型 ID | `doubao-seedance-2-5-260628` | confirmed，官方模型列表 S3；不得复用为 Fast/Mini/Pro ID |
| 普通生成时长 | `duration` 为 4–30 整数秒，或 `-1` 自动选择 | confirmed，API S2；不是提示词时间戳 |
| 输出分辨率 | 480p、720p、1080p | confirmed，S2/S3；本次不支持把 4K 当 2.5 输出参数 |
| 参考数量 | 最多 30 图、10 视频、10 音频，共 50 素材 | confirmed，教程 S1；数量上限不代表必须填满 |
| 视频参考时长 | 非编辑单段 2–30 秒；编辑待处理片 4–30 秒；视频合计不超过 30 秒 | confirmed，S2；核对任务类型 |
| 音频参考时长 | 单段 2–30 秒，音频合计不超过 30 秒 | confirmed，S2 |
| 纯音频参考输入 | 2.5 支持；不代表输出为纯音频 | confirmed，S1；不得沿用 2.0 必配视觉素材规则 |
| 时间控制 | 支持秒级区间、时间点、相对时间；逐帧准确性不作承诺 | confirmed，提示词指南 S4；见时间政策 |
| 编辑任务 | `ratio=adaptive`，`duration=-1`，有待编辑视频 | confirmed，S1/S2；时间戳是编辑范围，不是新片总长 |
| 首帧/首尾帧、延长 | `ratio=adaptive`；首尾帧须用对应结构化 role；延长须明确源视频与方向 | confirmed，S1/S2 |
| 延长长度解释 | 核实当前任务的 duration 语义，不能把源片总长、追加时长和输出总长混为一谈 | volatile，调用前 recheck S1/S2；撤回旧包“最长 60 秒”保证 |
| 30–180 秒超长模式 | 本次未核实 | unverified，禁止作为单次 API 能力；长片可分段规划 |
| Fast / Mini / Pro / flash | 不从标准模型推导 ID 或参数；flash 公告为 2026-11-15 14:00 起开放 | volatile，S1；开放时间、账户与实际入口须 recheck |
| 价格、即梦积分 | 不提供旧包固定报价 | volatile，须现场 recheck 当前模型、分辨率、输入视频、计费单位、地区与日期 |
| 更少参考、更少镜头 | 按信息职责与动作密度选择，不设固定“更稳张数”或“24秒必须5–7镜” | internal，导演规划建议；不是性能实测 |

## 官方来源

- S1：[2.5 教程](https://console.volcengine.com/ark/region:cn-beijing/docs/seedance-2-5)。
- S2：[创建视频任务 API](https://docs.volcengine.com/docs/ark/create-video-generation-task-api?lang=zh)。
- S3：[模型列表](https://console.volcengine.com/ark/region:cn-beijing/docs/model-list)。
- S4：[2.5 提示词指南](https://console.volcengine.com/ark/region:cn-beijing/docs/seedance-2-5-prompt-guide)。

平台有冲突时优先核对具体字段、具体任务与最新公告，保留冲突，不把日期较新自动等同于实测。统一时间规则见 [timing-policy](references/timing-policy.md)。
